import { Container } from "react-bootstrap"


export const Home = () => {
    return (
         
        <Container fluid>
            <h1>Welcome to Ananth's Book Store</h1>
        </Container>
    );
}